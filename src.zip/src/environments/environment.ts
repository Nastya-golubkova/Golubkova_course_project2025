// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl: 'https://localhost:44346',
  //apiUrl: 'https://d5eb-80-92-206-199.ngrok-free.app',
  //apiUrl: 'http://81.19.131.133:43444',
}

// ./ngrok.exe http https://localhost:44346/ --host-header="localhost:44346"
// ionic build --configuration=development
// npx cap sync android


