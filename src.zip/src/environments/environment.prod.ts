export const environment = {
  production: true,
  apiUrl: 'http://81.19.131.133:43444',
};
