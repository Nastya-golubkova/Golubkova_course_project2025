import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { filter, Subscription, take } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LoadingController, Platform } from '@ionic/angular';
import { MapPointService } from '../services/map-point.service';
import { FileService } from '../file.service';


@Component({
  selector: 'app-login',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss']
})
export class LoginPage {
  ltError = '';
  ltPhError = '';
  ltEmError = '';
  tokenEmail = '';
  version = '';
  step = 1;
  resendSec = 0;
  resendTimer: any;
  fakeSmsCode = '';
  environment = environment;

  form = new FormGroup({
    //'email': new FormControl('', [Validators.required, Validators.email, Validators.maxLength(200)]),
    'email': new FormControl('', [Validators.required, Validators.maxLength(128)]),
    'password': new FormControl('', [Validators.required]),
  });
  
  private subscriptions: Subscription[] = [];
  private bbSub: Subscription|undefined;

  constructor(
    private platform: Platform,
    private router: Router,
    private loadingController: LoadingController,    
    private mapPoint: MapPointService,
    public fileService: FileService,
  ) {
  }

  // Отключить back button
  ionViewDidEnter() {
    this.bbSub = this.platform.backButton.subscribeWithPriority(1, (processNextHandler) => { });
    console.log('proj-1', this.bbSub)
  }
  ionViewWillLeave() {   
    this.bbSub?.unsubscribe();
  }

  // Авторизоваться по смс
  async onLoginBySms() {
    console.log('2');
    /*this.ltError = '';
    if (!this.form.get('code')?.valid) {
      this.form.get('code')?.markAsTouched();
      return;
    }

    this.step = 1;    
    //const code = this.form.value.code;
    //this.form.get('code')?.patchValue('');
    //*/
  }

  check() {
    console.log('email', this.form.get('email')?.value);
    console.log('pass', this.form.get('password')?.value);
    this.fileService.userId = '';
    this.mapPoint.checkPassword$(this.form.get('email')?.value, this.form.get('password')?.value)
    .subscribe({
      next: res => {
        console.log(res);
        if (res.res != "neok") {
          this.fileService.userId = res.res;
          this.router.navigate(['tab2'], {queryParams : {param : res.res, name : res.name}});
        } else {
          window.alert("Неправильный логин или пароль");
        }
        
      }
    })

    
  }

  sign() {
    this.router.navigate(['sign']);
  }
}