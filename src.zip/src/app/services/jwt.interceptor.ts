import { HttpEvent, HttpHandlerFn, HttpInterceptorFn, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";

export const JwtInterceptor: HttpInterceptorFn = (
    request: HttpRequest<any>,
    next: HttpHandlerFn
) : Observable<HttpEvent<any>> => {
    /*
    const cloned = request.clone({
        setHeaders: {
            'ngrok-skip-browser-warning': '12345'
        }
    });
    return next(cloned);
    */
   return next(request);
}