import { HttpClient } from '@angular/common/http';
import { Injectable, ɵgetUnknownElementStrictMode } from '@angular/core';
import { Observable } from 'rxjs';
import { IMapPoint, IRoutes, IPlace, IPhoto, IApiPhoto } from '../model/map-point.interface';
import { environment } from 'src/environments/environment';
import { Marker } from 'leaflet';

@Injectable({
  providedIn: 'root'
})
export class MapPointService {
  private controller = 'MapPoint';
  private apiUrl = environment.apiUrl;


  constructor(
    private http: HttpClient,
  ) { 

  }

  gets$(userId: string): Observable<IMapPoint[]> {
    return this.http.get<IMapPoint[]>(`${this.apiUrl}/${this.controller}/gets/${userId}`);
  }

  post$(userId: string, placeId: string, lat: number, lng: number, name: string): Observable<{res: string}> {
    const data = {
      userId,
      placeId,
      lat,
      lng,
      name,
    };
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/post`, data);
    
  }

  delete$(userId: string, lat: number, lng: number): Observable<{res: string}> {
    const data = {
      userId,
      lat,
      lng,
    };
    return this.http.delete<{ res: string }>( `${this.apiUrl}/${this.controller}/delete/${userId}/${lat}/${lng}`,)
  }

  add_route$(UserId: string, NameRoute: string, arr: any): Observable<{res: string}> {
    var list_places: string[] = [];
    console.log(arr);
    for (var i = 0; i < arr.length; i++) {
      var place_id = arr[i].placeId;
      console.log(place_id)
      list_places.push(place_id);
    }
    const data = {
      UserId,
      NameRoute,
      PlaceIds : list_places
    };
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/addRoute`, data);
  }

  getRoutes$(UserId : string): Observable<IRoutes[]> {
    return this.http.get<IRoutes[]>(`${this.apiUrl}/${this.controller}/getRoutes/${UserId}`);
  }

  shareRoute$(UserId: string, NameRoute: string, UserLogin: string) : Observable<{res: string}> {
    const data = {
      UserId,
      NameRoute,
      UserLogin,
    }
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/shareRoute`, data);
  }

  enterCode$(UserId: string, Code: string) : Observable<{res: string}> {
    const data = {
      UserId,
      Code,
    }
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/enterCode`, data);
  }

  getCode$(UserId: string, nameRoute : string) : Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${this.controller}/getCode/${UserId}/${nameRoute}`);
  }

  addDescription$(UserId : string, PlaceId: string, Description : string) : Observable<{res: string}> {
    const data = {
      UserId,
      PlaceId,
      Description,
    }
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/addDescription`, data);
  }

  getPlaceInfo$(UserId : string, PlaceId : string): Observable<IPlace> {
    return this.http.get<IPlace>(`${this.apiUrl}/${this.controller}/getPlaceInfo/${UserId}/${PlaceId}`);

  }

  addName$ (UserId : string, PlaceId: string, Description : string) : Observable<{res: string}> {
    const data = {
      UserId,
      PlaceId,
      Description,
    }
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/addName`, data);
  }

  addPhoto$ (UserId : string, PlaceId: string, Image_ : any, Filename : any, Ext : any) : Observable<{res: string}> {
    const data = {
      UserId,
      PlaceId,
      Image_,
      Filename,
      Ext
    }
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/addPhoto`, data);
  }

  showPhotos$ (UserId : string, PlaceId: string) : Observable<IPhoto[]> {
    return this.http.get<IPhoto[]>(`${this.apiUrl}/${this.controller}/showPhotos/${UserId}/${PlaceId}`);
  }

  upload$(UserId : string, PlaceId: string, blob: Blob, Filename : any, Ext : any): Observable<{res: string}> {
    
    const formData = new FormData();
    /*formData.append('UserId', UserId);
    formData.append('PlaceId', PlaceId);
    formData.append('Image', Image_);
    formData.append('Filename', Filename);
    formData.append('Ext', Ext);*/
    //formData.append('ObjectUrl', ObjectUrl);
    console.log('upload$ length', blob?.size);
    console.log('UserId', UserId)
    formData.append('UserId', UserId);
    formData.append('PlaceId', PlaceId);
    formData.append('Image', blob);
    formData.append('Filename', Filename);
    formData.append('Ext', Ext);
    return this.http.post<{res: string}>(`${this.apiUrl}/${this.controller}/Photo`, formData);
  }

  download$(UserId: string, PlaceId: string): Observable<IApiPhoto[]> {
    return this.http.get<IApiPhoto[]>(`${this.apiUrl}/${this.controller}/Download/${UserId}/${PlaceId}`);
  }

  checkPassword$(email: any, pass : any) : Observable<{res: string, name: string}> {
    return this.http.get<{res : string, name: string}>(`${this.apiUrl}/${this.controller}/CheckPassword/${email}/${pass}`);
  }

  sign$(name : any, email : any, password : any) : Observable<{res : string}> {
    const data = {
      name,
      email,
      password,
    }
    return this.http.post<{res : string}>(`${this.apiUrl}/${this.controller}/Sign`, data);

  }


}
